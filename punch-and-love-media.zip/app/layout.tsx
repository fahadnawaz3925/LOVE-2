import "./globals.css"
import { Inter } from "next/font/google"
import type { Metadata } from "next"
import type React from "react" // Import React

// Optimize font loading with subset and weight range
const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: {
    default: "PUNCH & LOVE MEDIA",
    template: "%s | PUNCH & LOVE MEDIA",
  },
  description: "Search for people and discover their information through our comprehensive database",
  keywords: ["people search", "biography", "public figures", "media database"],
  themeColor: "#1f2937", // gray-800
  colorScheme: "dark",
  manifest: "/site.webmanifest",
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-16x16.png",
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://yourdomain.com",
    siteName: "PUNCH & LOVE MEDIA",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "PUNCH & LOVE MEDIA",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "PUNCH & LOVE MEDIA",
    description: "Search for people and discover their information",
    images: ["/twitter-image.jpg"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark scroll-smooth" suppressHydrationWarning>
      <head>
        {/* Preload critical resources */}
        <link
          rel="preload"
          href="/_next/static/media/inter.var.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
      </head>
      <body className={`${inter.variable} font-sans bg-gradient-to-b from-gray-900 to-gray-900`}>
        {/* Skip navigation link for accessibility */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:px-4 focus:py-2 focus:bg-gray-800 focus:text-white focus:rounded-lg"
        >
          Skip to main content
        </a>

        <main id="main-content" className="min-h-screen container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </main>

        {/* Optional: Add footer component here */}
      </body>
    </html>
  )
}



import './globals.css'