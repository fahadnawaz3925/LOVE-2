"use server"

// Define response interfaces for Wikipedia API
interface WikipediaResponse {
  query: {
    search: Array<{
      pageid: number
      title: string
      snippet: string
    }>
  }
}

interface WikipediaImageResponse {
  query: {
    pages: {
      [key: string]: {
        pageid: number
        title: string
        thumbnail?: {
          source: string
        }
        terms?: {
          description?: string[]
        }
        pageprops?: {
          wikibase_item?: string
        }
        original?: {
          source: string
        }
      }
    }
  }
}

interface WikidataDetails {
  isPerson: boolean
  birthDate: string | null
  currentAge: number | null
  country: string | null
}

// Configure constants for Wikipedia API
const WIKI_API_URL = "https://en.wikipedia.org/w/api.php"
const HEADERS = {
  "User-Agent": "PunchAndLoveMedia/1.0 (contact@example.com)",
  "Api-User-Agent": "PunchAndLoveMedia/1.0 (contact@example.com)",
}

// Helper: Compute age from a "YYYY-MM-DD" formatted birth date
function computeAge(birthDate: string): number {
  const today = new Date()
  const birth = new Date(birthDate)
  let age = today.getFullYear() - birth.getFullYear()
  const m = today.getMonth() - birth.getMonth()
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--
  }
  return age
}

// Helper: Fetch Wikidata label (e.g., country name) for a given entity ID
async function fetchWikidataLabel(entityId: string): Promise<string | null> {
  const params = new URLSearchParams({
    action: "wbgetentities",
    ids: entityId,
    props: "labels",
    languages: "en",
    format: "json",
    origin: "*",
  })
  const response = await fetch(`https://www.wikidata.org/w/api.php?${params.toString()}`)
  if (!response.ok) {
    throw new Error(`Failed to fetch label for ${entityId}`)
  }
  const data = await response.json()
  return data.entities?.[entityId]?.labels?.en?.value || null
}

// Helper: Fetch Wikidata details (birth date, country, and check if entity is a person)
// Returns additional properties along with a flag if the entity is a human (instance of Q5)
async function fetchWikidataDetails(wikidataId: string): Promise<WikidataDetails> {
  const params = new URLSearchParams({
    action: "wbgetentities",
    ids: wikidataId,
    props: "claims",
    format: "json",
    origin: "*",
  })
  const response = await fetch(`https://www.wikidata.org/w/api.php?${params.toString()}`)
  if (!response.ok) {
    throw new Error(`Failed to fetch Wikidata details for ${wikidataId}`)
  }
  const data = await response.json()
  const entity = data.entities?.[wikidataId]

  let isPerson = false
  let birthDate: string | null = null
  let country: string | null = null
  let currentAge: number | null = null

  // Verify the entity is a person: check if "instance of" (P31) includes human (Q5)
  if (entity?.claims?.P31) {
    for (const claim of entity.claims.P31) {
      if (claim.mainsnak.datavalue && claim.mainsnak.datavalue.value && claim.mainsnak.datavalue.value.id === "Q5") {
        isPerson = true
        break
      }
    }
  }

  // If not a person, exit early
  if (!isPerson) {
    return { isPerson, birthDate, currentAge, country }
  }

  // Fetch birth date (Property P569)
  if (entity.claims.P569 && entity.claims.P569.length > 0) {
    const dobTime: string = entity.claims.P569[0].mainsnak.datavalue.value.time
    // Example format: "+1962-08-22T00:00:00Z" → "1962-08-22"
    birthDate = dobTime ? dobTime.slice(1, 11) : null
    if (birthDate) {
      currentAge = computeAge(birthDate)
    }
  }

  // Fetch country of citizenship (Property P27)
  if (entity.claims.P27 && entity.claims.P27.length > 0) {
    const countryId: string = entity.claims.P27[0].mainsnak.datavalue.value.id
    try {
      country = await fetchWikidataLabel(countryId)
    } catch (error) {
      console.error("Error fetching country label:", error)
    }
  }

  return { isPerson, birthDate, currentAge, country }
}

export async function searchWikipedia(query: string, limit = 10) {
  // Validate parameters
  if (!query || typeof query !== "string") {
    throw new Error("Invalid search query")
  }

  const safeLimit = Math.min(limit, 50) // Cap results at 50 for safety

  try {
    // Fetch search results from Wikipedia
    const searchParams = new URLSearchParams({
      action: "query",
      list: "search",
      srsearch: query,
      format: "json",
      srlimit: safeLimit.toString(),
      origin: "*",
    })

    const searchResponse = await fetch(`${WIKI_API_URL}?${searchParams.toString()}`, { headers: HEADERS })
    if (!searchResponse.ok) {
      throw new Error(`Search failed: ${searchResponse.statusText}`)
    }
    const searchData: WikipediaResponse = await searchResponse.json()

    // Fetch additional metadata (images, description, and wikibase_item) for each result
    const pageIds = searchData.query.search.map((p) => p.pageid)
    const imageParams = new URLSearchParams({
      action: "query",
      prop: "pageimages|pageterms|pageprops",
      pageids: pageIds.join("|"),
      format: "json",
      piprop: "original", // Request original (full-size) image
      origin: "*",
    })

    const imageResponse = await fetch(`${WIKI_API_URL}?${imageParams.toString()}`, { headers: HEADERS })
    let imageData: WikipediaImageResponse | null = null
    if (imageResponse.ok) {
      imageData = await imageResponse.json()
    }

    // Process combined results:
    // For each result, use the Wikidata ID (if available) to fetch details.
    // Only include the result if it represents a person.
    const results = await Promise.all(
      searchData.query.search.map(async (result) => {
        const page = imageData?.query?.pages[result.pageid]
        const wikidataId = page?.pageprops?.wikibase_item
        if (!wikidataId) return null

        try {
          const details = await fetchWikidataDetails(wikidataId)
          if (!details.isPerson) return null

          return {
            id: result.pageid,
            name: result.title,
            description: page?.terms?.description?.[0] || "No description available",
            image: page?.original?.source || null, // Use the original (full-size) image
            birthDate: details.birthDate,
            currentAge: details.currentAge,
            country: details.country,
            snippet: result.snippet,
          }
        } catch (wikidataError) {
          console.error("Wikidata fetch error:", wikidataError)
          return null
        }
      }),
    )

    // Filter out null results (non-people or failed fetches)
    return results.filter((res) => res !== null)
  } catch (error) {
    console.error("Wikipedia search error:", error)
    throw new Error(`Search failed: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

