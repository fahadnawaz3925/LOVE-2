"use server";

import { SparqlEndpointFetcher } from "fetch-sparql-endpoint";

const fetcher = new SparqlEndpointFetcher();
const endpoint = "https://query.wikidata.org/sparql";

export async function searchPeople(query: string, limit = 10) {
  // Escape any double quotes to avoid breaking the SPARQL string literal
  const escapedQuery = query.replace(/"/g, '\\"');

  // Use regex for case-insensitive matching instead of LCASE & CONTAINS
  const sparqlQuery = `
    SELECT ?person ?personLabel ?countryLabel ?birthDate ?image WHERE {
      ?person wdt:P31 wd:Q5.
      ?person rdfs:label ?personLabel.
      FILTER(LANG(?personLabel) = "en")
      FILTER(regex(?personLabel, "${escapedQuery}", "i"))
      OPTIONAL { ?person wdt:P27 ?country. }
      OPTIONAL { ?person wdt:P569 ?birthDate. }
      OPTIONAL { ?person wdt:P18 ?image. }
      SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }
    }
    LIMIT ${limit}
  `;

  try {
    const bindingsStream = await fetcher.fetchBindings(endpoint, sparqlQuery);
    const results: Array<{
      id: string;
      name: string;
      country?: string;
      birthDate?: string | null;
      image?: string;
    }> = [];

    // Use destructuring for clarity
    for await (const binding of bindingsStream) {
      const { person, personLabel, countryLabel, birthDate, image } = binding;
      results.push({
        id: person.value,
        name: personLabel.value,
        country: countryLabel?.value ?? "Unknown",
        birthDate: birthDate
          ? new Date(birthDate.value).toISOString().split("T")[0]
          : null,
        image: image?.value ?? null,
      });
    }

    return results;
  } catch (error: any) {
    console.error("Error fetching data from Wikidata:", error);
    throw new Error(`Failed to fetch data from Wikidata: ${error.message || "Unknown error"}`);
  }
}

