"use client"

import Image from "next/image"
import { useState, useRef, useEffect } from "react"
import type { Person } from "@/lib/types"
import { Heart, FingerprintIcon as Fist } from "lucide-react"

interface PersonCardProps {
  person: Person
}

export default function PersonCard({ person }: PersonCardProps) {
  const [punches, setPunches] = useState(0)
  const [loves, setLoves] = useState(0)
  const [isPunching, setIsPunching] = useState(false)
  const [isLoving, setIsLoving] = useState(false)
  const imageRef = useRef<HTMLDivElement>(null)

  const handlePunch = () => {
    setPunches((prev) => prev + 1)
    setIsPunching(true)
  }

  const handleLove = () => {
    setLoves((prev) => prev + 1)
    setIsLoving(true)
  }

  useEffect(() => {
    if (isPunching) {
      const timer = setTimeout(() => setIsPunching(false), 500)
      return () => clearTimeout(timer)
    }
  }, [isPunching])

  useEffect(() => {
    if (isLoving) {
      const timer = setTimeout(() => setIsLoving(false), 500)
      return () => clearTimeout(timer)
    }
  }, [isLoving])

  return (
    <article className="bg-white rounded-lg shadow-xl overflow-hidden transition-all hover:shadow-2xl">
      <div
        ref={imageRef}
        className={`relative aspect-square ${isPunching ? "animate-punch" : ""} ${isLoving ? "animate-love" : ""}`}
      >
        {person.image ? (
          <Image
            src={person.image || "/placeholder.svg"}
            alt={`Portrait of ${person.name}`}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-cover"
            priority={false}
          />
        ) : (
          <div
            className="w-full h-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center"
            role="img"
            aria-label={`No image available for ${person.name}`}
          >
            <span className="text-white text-2xl font-bold">No Image</span>
          </div>
        )}
      </div>

      <div className="p-4 space-y-3">
        <h2 className="text-xl font-semibold text-[#1877F2]">{person.name}</h2>

        <div className="space-y-2 text-gray-600">
          {person.description && (
            <p className="text-sm line-clamp-3" title={person.description}>
              {person.description}
            </p>
          )}

          <div className="flex flex-wrap gap-2 text-sm">
            {person.country && <span className="px-2 py-1 bg-gray-100 rounded-md">🌍 {person.country}</span>}
            {person.birthDate && <span className="px-2 py-1 bg-gray-100 rounded-md">🎂 {person.birthDate}</span>}
          </div>

          {person.snippet && (
            <p className="text-xs text-gray-500 line-clamp-2" dangerouslySetInnerHTML={{ __html: person.snippet }} />
          )}
        </div>

        <div className="flex justify-between items-center mt-4">
          <button
            onClick={handlePunch}
            className="flex items-center space-x-1 px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
          >
            <Fist size={16} />
            <span>{punches}</span>
          </button>
          <button
            onClick={handleLove}
            className="flex items-center space-x-1 px-3 py-1 bg-pink-500 text-white rounded-md hover:bg-pink-600 transition-colors"
          >
            <Heart size={16} />
            <span>{loves}</span>
          </button>
        </div>
      </div>
    </article>
  )
}

