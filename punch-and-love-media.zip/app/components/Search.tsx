"use client"

import { useState, useEffect, useCallback } from "react"
import { useDebounce } from "use-debounce"
import { searchWikipedia } from "../actions/searchWikipedia"
import Results from "./Results"
import type { Person } from "@/lib/types"

export default function Search() {
  const [query, setQuery] = useState("")
  const [debouncedQuery] = useDebounce(query, 300)
  const [results, setResults] = useState<Person[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [activeSuggestion, setActiveSuggestion] = useState(-1)

  const fetchResults = useCallback(async (signal: AbortSignal, searchQuery: string) => {
    try {
      const data = await searchWikipedia(searchQuery)
      if (!signal.aborted) {
        setResults(data)
        setError(null)
      }
    } catch (err) {
      if (!signal.aborted) {
        console.error("Search error:", err)
        setError(err instanceof Error ? err.message : "Failed to fetch results")
        setResults([])
      }
    } finally {
      if (!signal.aborted) setLoading(false)
    }
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    const signal = controller.signal

    if (debouncedQuery.length > 2) {
      setLoading(true)
      fetchResults(signal, debouncedQuery)
    } else {
      setResults([])
      setError(null)
    }

    return () => controller.abort()
  }, [debouncedQuery, fetchResults])

  const fetchSuggestions = useCallback(async (signal: AbortSignal, searchQuery: string) => {
    try {
      const data = await searchWikipedia(searchQuery, 5)
      if (!signal.aborted) {
        setSuggestions(data.map((item) => item.name))
      }
    } catch (err) {
      if (!signal.aborted) {
        console.error("Suggestions error:", err)
        setSuggestions([])
      }
    }
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    const signal = controller.signal

    if (query.length > 2) {
      fetchSuggestions(signal, query)
    } else {
      setSuggestions([])
    }

    return () => controller.abort()
  }, [query, fetchSuggestions])

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value)
    setActiveSuggestion(-1)
  }

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion)
    setSuggestions([])
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (suggestions.length === 0) return

    if (e.key === "ArrowDown") {
      e.preventDefault()
      setActiveSuggestion((prev) => Math.min(prev + 1, suggestions.length - 1))
    } else if (e.key === "ArrowUp") {
      e.preventDefault()
      setActiveSuggestion((prev) => Math.max(prev - 1, -1))
    } else if (e.key === "Enter" && activeSuggestion >= 0) {
      e.preventDefault()
      handleSuggestionClick(suggestions[activeSuggestion])
    }
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={handleQueryChange}
          onKeyDown={handleKeyDown}
          placeholder="Search for a person..."
          aria-label="Search for people on Wikipedia"
          aria-autocomplete="list"
          aria-controls="suggestions-list"
          className="w-full p-4 border-2 border-[#1877F2] rounded-lg bg-white text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
        />

        {suggestions.length > 0 && (
          <ul
            id="suggestions-list"
            role="listbox"
            className="absolute z-10 w-full bg-white border-2 border-[#1877F2] rounded-lg mt-1 shadow-lg"
          >
            {suggestions.map((suggestion, index) => (
              <li
                key={suggestion}
                role="option"
                aria-selected={index === activeSuggestion}
                onClick={() => handleSuggestionClick(suggestion)}
                onMouseEnter={() => setActiveSuggestion(index)}
                className={`p-2 cursor-pointer text-gray-800 ${
                  index === activeSuggestion ? "bg-gray-100" : "hover:bg-gray-100"
                }`}
              >
                {suggestion}
              </li>
            ))}
          </ul>
        )}
      </div>

      <Results results={results} isLoading={loading} error={error} className="mt-8" />
    </div>
  )
}

