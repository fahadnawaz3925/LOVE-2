import PersonCard from "./PersonCard"
import type { Person } from "@/lib/types"

interface ResultsProps {
  results: Person[]
  isLoading?: boolean
  error?: string | null
  className?: string
}

export default function Results({ results, isLoading = false, error = null, className = "" }: ResultsProps) {
  if (error) {
    return (
      <div className={`text-center py-12 text-red-500 ${className}`}>
        <p>🚨 Error loading results:</p>
        <p className="mt-2 text-sm opacity-75">{error}</p>
      </div>
    )
  }

  if (!isLoading && results.length === 0) {
    return (
      <div className={`text-center py-12 text-gray-500 ${className}`}>
        <p>🔍 No results found</p>
        <p className="mt-2 text-sm opacity-75">Try different search terms</p>
      </div>
    )
  }

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${className}`}>
      {isLoading
        ? // Skeleton loading states
          Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-xl overflow-hidden animate-pulse">
              <div className="aspect-square bg-gray-200" />
              <div className="p-4 space-y-3">
                <div className="h-6 bg-gray-200 rounded w-3/4" />
                <div className="h-4 bg-gray-200 rounded w-1/2" />
                <div className="h-4 bg-gray-200 rounded w-2/3" />
              </div>
            </div>
          ))
        : results.map((person) => <PersonCard key={person.id} person={person} />)}
    </div>
  )
}

