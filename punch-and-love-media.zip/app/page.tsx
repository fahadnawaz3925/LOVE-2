import Search from "./components/Search"
import Head from "next/head"

export default function Home() {
  return (
    <>
      <Head>
        <title>Punch & Love Media - Unbiased Social Mirror</title>
        <meta
          name="description"
          content="Explore unbiased insights into public figures and social impact through Punch & Love Media's neutral analysis platform."
        />
        <meta
          name="keywords"
          content="social analysis, public figures, impact metrics, unbiased reporting, Punch & Love Media"
        />
      </Head>

      <main className="relative flex flex-col items-center justify-center min-h-screen overflow-hidden py-12 bg-gradient-to-r from-[#1877F2] to-[#4267B2]">
        {/* Skip to Content Link for Accessibility */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:bg-white focus:p-4 focus:rounded-lg focus:text-[#1877F2]"
        >
          Skip to main content
        </a>

        <div
          id="main-content"
          className="relative z-10 flex flex-col items-center justify-center w-full px-4"
          role="main"
        >
          {/* Header Section */}
          <header className="text-center mb-12">
            <h1 className="text-6xl md:text-8xl font-extrabold mb-4 text-white drop-shadow-lg">PUNCH & LOVE MEDIA</h1>
            <p className="text-2xl md:text-3xl text-gray-200 mb-8 max-w-3xl mx-auto tracking-wider">
              Unveiling the Human Mosaic - Unbiased Mirror of the Society
            </p>
          </header>

          <div className="w-full max-w-4xl space-y-16">
            {/* Search Section */}
            <section
              aria-labelledby="search-section-title"
              className="bg-white rounded-3xl p-10 shadow-2xl border border-gray-200"
            >
              <div className="space-y-8">
                <h2 id="search-section-title" className="text-3xl md:text-4xl font-bold text-[#1877F2] text-center">
                  Who do you want to Punch or Love?
                </h2>
                <Search />
                <p className="text-lg text-gray-600 text-center">
                  Search for any public figure, historical personality, or contemporary influencer.
                </p>
              </div>
            </section>

            {/* Feature Cards */}
            <div role="region" aria-labelledby="features-title" className="grid md:grid-cols-3 gap-10">
              <h3 id="features-title" className="sr-only">
                Key Features
              </h3>
              {["Unfiltered Insights", "Neutral Perspective", "Dynamic Context"].map((feature, index) => (
                <article
                  key={index}
                  className="bg-white p-10 rounded-2xl border border-gray-200 shadow-xl transform hover:scale-105 transition-transform duration-300 focus-within:scale-105"
                  tabIndex={0}
                  role="button"
                  aria-label={`Learn more about ${feature}`}
                >
                  <h3 className="font-bold mb-4 text-[#1877F2] text-xl">{feature}</h3>
                  <p className="text-md text-gray-700">
                    {feature === "Unfiltered Insights" &&
                      "Direct access to verified public records and historical data."}
                    {feature === "Neutral Perspective" && "Algorithmically balanced presentation of information."}
                    {feature === "Dynamic Context" && "Real-time social impact analysis and relevance scoring."}
                  </p>
                </article>
              ))}
            </div>

            {/* Most Punched Section */}
            <section
              aria-labelledby="most-punched-title"
              className="bg-white rounded-3xl p-10 shadow-2xl border border-gray-200"
            >
              <div className="space-y-8">
                <h2 id="most-punched-title" className="text-3xl md:text-4xl font-bold text-[#1877F2] text-center">
                  Most Punched and Loved Highlights
                </h2>
                <div className="grid md:grid-cols-3 gap-10">
                  {[
                    { period: "Day", description: "Today's standout figures based on real-time impact metrics" },
                    { period: "Week", description: "Weekly top performers recognized for significant influence" },
                    { period: "Year", description: "Annual champions for remarkable impact" },
                  ].map((item, index) => (
                    <article
                      key={index}
                      className="bg-white p-10 rounded-2xl border border-gray-200 shadow-xl transform hover:scale-105 transition-transform duration-300 focus-within:scale-105"
                      tabIndex={0}
                      role="article"
                      itemScope
                      itemType="https://schema.org/Ranking"
                    >
                      <h3 className="font-bold mb-4 text-[#1877F2] text-xl" itemProp="name">
                        MOST PUNCHED & LOVED OF THE {item.period.toUpperCase()}
                      </h3>
                      <p className="text-md text-gray-700" itemProp="description">
                        {item.description}
                      </p>
                      <meta itemProp="rankingSystem" content="Social Impact Metrics" />
                    </article>
                  ))}
                </div>
              </div>
            </section>
          </div>
        </div>

        {/* Footer Accessibility */}
        <footer className="mt-16 text-center text-white" role="contentinfo">
          <p aria-label="Copyright information">
            © {new Date().getFullYear()} Punch & Love Media. All rights reserved.
          </p>
        </footer>
      </main>
    </>
  )
}

