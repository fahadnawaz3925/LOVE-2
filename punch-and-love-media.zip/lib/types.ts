export interface Person {
  id: number
  name: string
  description?: string
  image?: string | null
  birthDate?: string | null
  currentAge?: number | null
  country?: string | null
  snippet?: string
}

